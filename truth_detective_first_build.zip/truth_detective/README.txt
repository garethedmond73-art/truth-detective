THE TRUTH DETECTIVE — FIRST PHONE-READY PROTOTYPE

This is an installable Progressive Web App. It runs in a modern browser and can be added to an Android home screen when hosted over HTTPS.

Features: case board; Scripture/Science/Philosophy/Human Experience categories; evidence ledger; source, support, challenge and assessment fields; filters; edit/delete; provisional case report; offline cache; local browser storage.

To install: host the contents of this folder on an HTTPS static host (for example GitHub Pages), open its address in Chrome on Android, then use Chrome menu > Add to Home screen / Install app.

Limitations: this version does not automatically search all world scriptures, academic literature or the internet. It organises evidence and keeps uncertainty visible. Evidence is stored only in this browser on this device; clearing browser data can erase it. Back up important notes separately.

Next stages: trusted searchable source collections, citations and source-quality checks, contradiction/claim maps, backup/export, AI-assisted synthesis with citations, then Android APK packaging.
